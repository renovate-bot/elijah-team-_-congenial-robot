/**
 *
 */
package tripleo.elijah.lang.impl;

/**
 * @author Tripleo
 * <p>
 * Created 	Mar 27, 2020 at 1:13:13 AM
 */
public enum NamespaceModify {
	IMPORT
}

//
//
//
